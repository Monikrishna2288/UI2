import { ComponentRegistry } from 'mystique/registry/ComponentRegistry';
import { Hello } from './components/_examples/Hello';

ComponentRegistry.register(['fc.hello'], Hello, {category: 'content'});