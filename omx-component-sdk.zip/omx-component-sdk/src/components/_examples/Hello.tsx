import { Card } from 'mystique/components/Card';
import { CardContent } from 'mystique/components/CardContent';
import { OperationResult } from 'mystique/hooks/getQuery';
import { useQuery } from 'mystique/hooks/useQuery';

// Tip: add comments to your component props so that they automatically appear as documentation in Storybook
export interface Props {
  /**
  The text to appear in the component
  */
  content: string;
}

const meQuery = `
  query {
    me{
      id
      username
    }
  }
`;

interface User {
  id: string
  ref: string
  username: string
}
interface MeQueryResponse extends OperationResult {
  me: User
}

export const Hello: React.FC<Props> = (props: Props) => {
  const [response] = useQuery<MeQueryResponse>(meQuery);
  const cardContent = response.data !== undefined ? `${props.content} ${response.data?.me.username}` : 'Loading...';
  return <HelloCard content={cardContent} />;
};

export const HelloCard: React.FC<Props> = (props: Props) =>
  <Card title={'Hello World'}>
    <CardContent>
      <p data-testid='hello-content'>{props.content}</p>
    </CardContent>
  </Card>;
