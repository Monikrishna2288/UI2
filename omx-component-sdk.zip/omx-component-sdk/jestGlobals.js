/** @type {jest.Expect} */

const expect = global.expect

export { expect }